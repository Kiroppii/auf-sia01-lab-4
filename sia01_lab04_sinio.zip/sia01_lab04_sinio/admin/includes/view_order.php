<?php
include "ecommerce/Order.php";
include "ecommerce/OrderItem.php";
include "ecommerce/Product.php";

// Handle status update from admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status']) && isset($_GET['order_id'])) {
    $new_status = $_POST['status'] ?? '';
    $orderToUpdate = new Order($connection);
    // Use existing values for user_id and total_amount when updating
    $order_result_temp = $orderToUpdate->find((int)$_GET['order_id']);
    if ($order_result_temp && $rowTemp = mysqli_fetch_assoc($order_result_temp)) {
        $orderToUpdate->update((int)$_GET['order_id'], ['user_id' => $rowTemp['user_id'], 'total_amount' => $rowTemp['total_amount'], 'status' => $new_status]);
        // reload page to reflect changes
        header('Location: orders.php?order_id=' . (int)$_GET['order_id']);
        exit;
    }
}

if (!isset($_GET['order_id'])) {
    echo "<div class='alert alert-warning'>No order selected.</div>";
    return;
}

$order_id = (int)$_GET['order_id'];
$order = new Order($connection);
$order_result = $order->find($order_id);
if (!$order_result || mysqli_num_rows($order_result) == 0) {
    echo "<div class='alert alert-danger'>Order not found.</div>";
    return;
}
$order_row = mysqli_fetch_assoc($order_result);

// Fetch customer info
$user_id = $order_row['user_id'];
$customer_name = '';
$customer_email = '';
$stmt = mysqli_prepare($connection, "SELECT user_firstname, user_lastname, user_email FROM users WHERE user_id = ?");
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($r = $res->fetch_assoc()) {
        $customer_name = trim(($r['user_firstname'] ?? '') . ' ' . ($r['user_lastname'] ?? ''));
        $customer_email = $r['user_email'] ?? '';
    }
}

$total_amount = $order_row['total_amount'];
$order_date = $order_row['order_date'];
$status = $order_row['status'];

?>

<a class="btn btn-default" href="orders.php">&larr; Back to Orders</a>

<h2>Order #<?php echo htmlspecialchars($order_id); ?></h2>

<div class="panel panel-default">
    <div class="panel-heading">Customer Information</div>
    <div class="panel-body">
        <p><strong>Name:</strong> <?php echo htmlspecialchars($customer_name ?: ''); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($customer_email ?: ''); ?></p>
        <p><strong>User:</strong> <?php echo htmlspecialchars(($customer_name ?: $customer_email) ? ($customer_name ?: $customer_email) : 'User ID: ' . $user_id); ?></p>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">Order Information</div>
    <div class="panel-body">
        <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order_date); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($status); ?></p>
        <p><strong>Total:</strong> $<?php echo number_format($total_amount, 2); ?></p>

        <form method="post" class="form-inline">
            <div class="form-group">
                <label for="status">Change Status: </label>
                <select name="status" class="form-control" style="margin-left:8px;margin-right:8px;">
                    <option value="pending" <?php echo ($status=='pending')? 'selected':''; ?>>pending</option>
                    <option value="confirmed" <?php echo ($status=='confirmed')? 'selected':''; ?>>confirmed</option>
                    <option value="done" <?php echo ($status=='done')? 'selected':''; ?>>done</option>
                    <option value="shipped" <?php echo ($status=='shipped')? 'selected':''; ?>>shipped</option>
                </select>
            </div>
            <button type="submit" name="update_status" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>

<div class="panel panel-default">
    <div class="panel-heading">Ordered Items</div>
    <div class="panel-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $orderItem = new OrderItem($connection);
                $items = $orderItem->getByOrderId($order_id);
                if ($items && mysqli_num_rows($items) > 0) {
                    while ($it = mysqli_fetch_assoc($items)) {
                        $prod = new Product($connection);
                        $pRes = $prod->find($it['product_id']);
                        $pName = '(product removed)';
                        if ($pRes && $pRow = mysqli_fetch_assoc($pRes)) {
                            $pName = $pRow['name'];
                        }
                        $subtotal = $it['price'] * $it['quantity'];
                        echo "<tr><td>" . htmlspecialchars($pName) . "</td><td>$" . number_format($it['price'],2) . "</td><td>" . (int)$it['quantity'] . "</td><td>$" . number_format($subtotal,2) . "</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No items found for this order.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
