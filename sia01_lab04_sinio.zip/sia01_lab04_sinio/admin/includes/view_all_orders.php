<?php
include "./includes/ecommerce/Order.php";
include "./includes/ecommerce/OrderItem.php";
include "./includes/ecommerce/Product.php";

?>

<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Total Amount</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $order = new Order($connection);
        $all_orders = $order->all();
        while ($row = mysqli_fetch_assoc($all_orders)) {

            $order_id = $row['order_id'];
            $user_id = $row['user_id'];
            $customer = trim($row['customer'] ?? '');
            // If the concatenated customer name is empty, try to fetch the username from users table
            if (empty($customer)) {
                $uStmt = mysqli_prepare($connection, "SELECT user_name FROM users WHERE user_id = ?");
                if ($uStmt) {
                    $uStmt->bind_param('i', $user_id);
                    $uStmt->execute();
                    $uRes = $uStmt->get_result();
                    if ($uRow = $uRes->fetch_assoc()) {
                        $customer = $uRow['user_name'] ?: $customer;
                    }
                }
            }
            $total_amount = $row['total_amount'];
            $order_date = $row['order_date'];
            $status = $row['status'];

            $displayCustomer = $customer ?: 'User ID: ' . $user_id;
            echo "<tr>
                    <td>$order_id</td>
                    <td>" . htmlspecialchars($displayCustomer) . "</td>
                    <td>$total_amount</td>
                    <td>$order_date</td>
                    <td>$status</td>
                    <td>
                        <a class='btn btn-sm btn-info' href='orders.php?order_id=$order_id'>View</a>
                    </td>
                </tr>";
        }
        ?>
    </tbody>
</table>
