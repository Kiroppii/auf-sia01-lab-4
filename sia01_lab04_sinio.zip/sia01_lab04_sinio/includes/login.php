<?php
include "db.php";
session_start();

if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $_SESSION['auth_error'] = 'Username and password are required.';
        header("Location: ../index.php");
        exit;
    }

    $stmt = mysqli_prepare($connection, "SELECT * FROM users WHERE user_name = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $select_user_query = $stmt->get_result();
        $stmt->close();
    } else {
        die("Query Failed: " . mysqli_error($connection));
    }

    $Row = $select_user_query ? mysqli_fetch_assoc($select_user_query) : null;

    if ($Row) {
        $user_id = $Row['user_id'];
        $user_role = $Row['user_role'];
        $user_name = $Row['user_name'];
        $user_firstname = $Row['user_firstname'];
        $user_lastname = $Row['user_lastname'];
    $user_password = $Row['user_password'];
    $user_password_trim = trim($user_password);
    $user_salt_raw = $Row['randSalt'] ?? '';
    $user_salt_trim = trim($user_salt_raw);
    $legacy_two_char_salt = substr($user_salt_raw, 0, 2);

        // Password validation: bcrypt, plain (legacy), md5/sha1, crypt with stored hash, crypt with stored salt
        $isValidPassword = false;

        // 1) password_hash / bcrypt
        if (password_verify($password, $user_password)) {
            $isValidPassword = true;
        }

        // 2) Plain text / trimmed plain (covers unencrypted admin passwords)
        if (!$isValidPassword && ($password === $user_password || $password === $user_password_trim)) {
            $isValidPassword = true;
        }

        // 3) Legacy md5 or sha1 hashes
        if (!$isValidPassword && (md5($password) === $user_password || sha1($password) === $user_password)) {
            $isValidPassword = true;
        }

        // 4) Legacy crypt hash using stored hash as salt
        if (!$isValidPassword) {
            $cryptAttempt = crypt($password, $user_password);
            if (!empty($user_password) && (hash_equals($user_password, $cryptAttempt) || hash_equals($user_password_trim, trim($cryptAttempt)))) {
                $isValidPassword = true;
            }
        }

        // 5) Legacy crypt hash using raw randSalt with password provided as salt (old registration bug crypt($salt, $password) with untrimmed salt)
        if (!$isValidPassword && $user_salt_raw !== '') {
            $legacyBrokenHashRaw = crypt($user_salt_raw, $password);
            if (!empty($user_password) && (hash_equals($user_password, $legacyBrokenHashRaw) || hash_equals($user_password_trim, trim($legacyBrokenHashRaw)))) {
                $isValidPassword = true;
            }
        }

        // 6) Legacy crypt hash using trimmed randSalt with password provided as salt (covers cases where spaces were trimmed in DB)
        if (!$isValidPassword && $user_salt_trim !== '') {
            $legacyBrokenHashTrim = crypt($user_salt_trim, $password);
            if (!empty($user_password) && (hash_equals($user_password, $legacyBrokenHashTrim) || hash_equals($user_password_trim, trim($legacyBrokenHashTrim)))) {
                $isValidPassword = true;
            }
        }

        // 7) Legacy DES-style crypt using first 2 chars of randSalt (matches very short hashes like "kiw0gWOuSPGs")
        if (!$isValidPassword && $legacy_two_char_salt !== '') {
            $desHash = crypt($password, $legacy_two_char_salt);
            if (!empty($user_password) && (hash_equals($user_password, $desHash) || hash_equals($user_password_trim, trim($desHash)))) {
                $isValidPassword = true;
            }
        }

        // 8) Legacy DES-style crypt using first 2 chars of stored password as salt (fallback)
        if (!$isValidPassword && strlen($user_password) >= 2) {
            $desSaltFromPassword = substr($user_password, 0, 2);
            $desHash2 = crypt($password, $desSaltFromPassword);
            if (!empty($user_password) && (hash_equals($user_password, $desHash2) || hash_equals($user_password_trim, trim($desHash2)))) {
                $isValidPassword = true;
            }
        }

        // Username match is case-insensitive to avoid surprises
        $isSameUser = strcasecmp($username, $user_name) === 0;

        if ($isSameUser && $isValidPassword) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $user_name;
            $_SESSION['firstname'] = $user_firstname;
            $_SESSION['lastname'] = $user_lastname;
            $_SESSION['role'] = $user_role;
            $displayName = trim($user_firstname . ' ' . $user_lastname);
            if ($displayName === '') {
                $displayName = $user_name;
            }
            $_SESSION['auth_success'] = "Welcome back, {$displayName}!";

            // Admins go to dashboard, others to homepage
            if (strtolower($user_role) === 'admin') {
                header("Location: ../admin/index.php");
            } else {
                header("Location: ../index.php");
            }
            exit;
        }
    }

    // If we reach here, login failed
    $_SESSION['auth_error'] = 'Invalid username or password.';
    header("Location: ../index.php");
    exit;
}
