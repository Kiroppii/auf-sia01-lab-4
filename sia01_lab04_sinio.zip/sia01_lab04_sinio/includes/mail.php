<?php
// Mail helper using Mailtrap Send API (requires MAILTRAP_API_TOKEN)
// Copy includes/mail_config.php.example -> includes/mail_config.php and fill your token.
if (file_exists(__DIR__ . '/mail_config.php')) {
    include_once __DIR__ . '/mail_config.php';
}

function mailtrap_send($to_email, $to_name, $subject, $html_body, $text_body = '') {
    if (!defined('MAILTRAP_API_TOKEN') || empty(MAILTRAP_API_TOKEN)) {
        error_log('Mailtrap API token not defined. Please create includes/mail_config.php from the example.');
        return false;
    }

    $url = 'https://send.api.mailtrap.io/api/send';

    $from_email = defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'no-reply@example.com';
    $from_name = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'My Shop';

    $payload = [
        'from' => [
            'email' => $from_email,
            'name' => $from_name
        ],
        'to' => [
            [
                'email' => $to_email,
                'name' => $to_name
            ]
        ],
        'subject' => $subject,
        'text' => $text_body,
        'html' => $html_body
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . MAILTRAP_API_TOKEN
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if (defined('MAIL_DEBUG') && MAIL_DEBUG) {
        file_put_contents(__DIR__ . '/mail_debug.log', date('c') . " HTTP:$httpcode\n" . $response . "\n\n", FILE_APPEND);
    }

    if ($response === false || $httpcode < 200 || $httpcode >= 300) {
        error_log("Mailtrap send failed (code: $httpcode): $curlErr Response: $response");
        return false;
    }

    return true;
}

// Wrapper that prefers SMTP when configured.
function send_mail($to_email, $to_name, $subject, $html_body, $text_body = '') {
    if (defined('MAIL_USE_SMTP') && MAIL_USE_SMTP) {
        // try using SMTP helper
        if (!file_exists(__DIR__ . '/mail_smtp.php')) {
            error_log('mail_smtp.php not found - cannot send via SMTP');
            return false;
        }
        include_once __DIR__ . '/mail_smtp.php';
        return smtp_send($to_email, $to_name, $subject, $html_body, $text_body);
    }

    // Fallback to Mailtrap Send API
    return mailtrap_send($to_email, $to_name, $subject, $html_body, $text_body);
}
