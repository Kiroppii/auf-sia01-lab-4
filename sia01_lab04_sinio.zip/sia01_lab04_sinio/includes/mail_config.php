<?php
// Mail configuration (generated from user-provided Mailtrap sandbox credentials)
// WARNING: this file contains sensitive credentials. Do not commit to version control.

// Use SMTP (PHPMailer) - set to true to enable SMTP sending
define('MAIL_USE_SMTP', true);

// Mailtrap SMTP sandbox settings
define('MAIL_SMTP_HOST', 'sandbox.smtp.mailtrap.io');
define('MAIL_SMTP_PORT', 2525);
define('MAIL_SMTP_USERNAME', '1419b99097ea40');
define('MAIL_SMTP_PASSWORD', 'ca0d2ec88f5bb4');
define('MAIL_SMTP_ENCRYPTION', null); // 'tls' or 'ssl' or null

// Sender info
define('MAIL_FROM_EMAIL', 'no-reply@yourshop.test');
define('MAIL_FROM_NAME', 'My Shop');

// Debug: set to true to log PHPMailer/Send API activity to logs
define('MAIL_DEBUG', true);

return true;
