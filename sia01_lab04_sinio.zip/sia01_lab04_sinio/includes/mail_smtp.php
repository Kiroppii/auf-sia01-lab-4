<?php
// SMTP mail helper using PHPMailer. Requires phpmailer/phpmailer installed via Composer.
// Usage: smtp_send($to_email, $to_name, $subject, $html_body, $text_body='')

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (file_exists(__DIR__ . '/mail_config.php')) {
    include_once __DIR__ . '/mail_config.php';
}

function smtp_send($to_email, $to_name, $subject, $html_body, $text_body = '') {
    // Ensure PHPMailer is available (composer autoload)
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (!file_exists($autoload)) {
        error_log('PHPMailer not found. Run: composer require phpmailer/phpmailer');
        return false;
    }

    require_once $autoload;

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $host = defined('MAIL_SMTP_HOST') ? MAIL_SMTP_HOST : '';
        $port = defined('MAIL_SMTP_PORT') ? MAIL_SMTP_PORT : 2525;
        $username = defined('MAIL_SMTP_USERNAME') ? MAIL_SMTP_USERNAME : '';
        $password = defined('MAIL_SMTP_PASSWORD') ? MAIL_SMTP_PASSWORD : '';
        $encryption = defined('MAIL_SMTP_ENCRYPTION') ? MAIL_SMTP_ENCRYPTION : null;

        if (!$host || !$username) {
            error_log('SMTP configuration is incomplete. Please set MAIL_SMTP_HOST and MAIL_SMTP_USERNAME.');
            return false;
        }

        $mail->Host = $host;
        $mail->Port = $port;
        $mail->SMTPAuth = true;
        $mail->Username = $username;
        $mail->Password = $password;
        if ($encryption) {
            $mail->SMTPSecure = $encryption;
        }

        // From
        $from_email = defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'no-reply@example.com';
        $from_name = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'My Shop';
        $mail->setFrom($from_email, $from_name);

        // To
        $mail->addAddress($to_email, $to_name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html_body;
        if (!empty($text_body)) {
            $mail->AltBody = $text_body;
        }

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $mail->ErrorInfo);
        return false;
    }
}
