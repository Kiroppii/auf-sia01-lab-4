<?php
// Simple SMTP test using PHPMailer and your includes/mail_config.php
// Visit http://localhost/sia01_lab04_sinio/mail_test_smtp.php in your browser to run.

require __DIR__ . '/includes/mail_config.php';

// Check composer autoload
$autoload = __DIR__ . '/vendor/autoload.php';
if (!file_exists($autoload)) {
    echo "PHPMailer not installed. Run: <code>composer require phpmailer/phpmailer</code> in project root.";
    exit;
}
require $autoload;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = MAIL_SMTP_HOST;
    $mail->Port = MAIL_SMTP_PORT;
    $mail->SMTPAuth = true;
    $mail->Username = MAIL_SMTP_USERNAME;
    $mail->Password = MAIL_SMTP_PASSWORD;
    if (defined('MAIL_SMTP_ENCRYPTION') && MAIL_SMTP_ENCRYPTION) {
        $mail->SMTPSecure = MAIL_SMTP_ENCRYPTION;
    }

    $mail->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
    $mail->addAddress(MAIL_FROM_EMAIL, MAIL_FROM_NAME);

    $mail->isHTML(true);
    $mail->Subject = 'Mailtrap SMTP test from local site';
    $mail->Body = '<p>This is a <strong>test</strong> email sent via Mailtrap SMTP sandbox.</p>';
    $mail->AltBody = 'This is a test email sent via Mailtrap SMTP sandbox.';

    $mail->send();
    echo '<h3>SMTP test sent. Check your Mailtrap inbox (Sandbox) for the message.</h3>';
} catch (Exception $e) {
    echo '<h3>PHPMailer error:</h3><pre>' . htmlspecialchars($mail->ErrorInfo) . '</pre>';
}
