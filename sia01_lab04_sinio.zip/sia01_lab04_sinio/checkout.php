<?php
include "includes/db.php";
/* Page Header and navigation */
include "includes/header.php";
include "includes/navigation.php";
require_once __DIR__ . '/admin/includes/ecommerce/Order.php';
require_once __DIR__ . '/admin/includes/ecommerce/OrderItem.php';
require_once __DIR__ . '/includes/mail.php';

// Ensure cart exists and has items
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<div class='container'><div class='alert alert-info'>Your cart is empty. <a href='shop.php'>Continue shopping</a></div></div>";
    include "includes/footer.php";
    exit;
}

// Require logged-in user to create order
if (!isset($_SESSION['user_id']) || !is_numeric($_SESSION['user_id'])) {
    echo "<div class='container'><div class='alert alert-warning'>You must be logged in to checkout. <a href='registration.php'>Login / Register</a></div></div>";
    include "includes/footer.php";
    exit;
}

$cart = $_SESSION['cart'];
$total_amount = 0.0;
foreach ($cart as $item) {
    $total_amount += ($item['price'] * $item['quantity']);
}

$order = new Order($connection);

// Verify stock for each item before creating order
$insufficient = [];
foreach ($cart as $product_id => $item) {
    $pid = (int)$item['product_id'];
    $q = mysqli_prepare($connection, "SELECT stock_quantity FROM products WHERE product_id = ?");
    if ($q) {
        $q->bind_param('i', $pid);
        $q->execute();
        $res = $q->get_result();
        if ($row = $res->fetch_assoc()) {
            $stock = (int)$row['stock_quantity'];
            if ($stock < (int)$item['quantity']) {
                $insufficient[] = ['product_id' => $pid, 'name' => $item['name'], 'stock' => $stock, 'requested' => (int)$item['quantity']];
            }
        } else {
            $insufficient[] = ['product_id' => $pid, 'name' => $item['name'], 'stock' => 0, 'requested' => (int)$item['quantity']];
        }
    }
}

if (!empty($insufficient)) {
    echo "<div class='container'><div class='alert alert-danger'><strong>Unable to place order. Insufficient stock for:</strong><ul>";
    foreach ($insufficient as $ii) {
        echo "<li>" . htmlspecialchars($ii['name']) . " — requested: " . (int)$ii['requested'] . ", available: " . (int)$ii['stock'] . "</li>";
    }
    echo "</ul><a href='cart.php' class='btn btn-primary'>Return to Cart</a></div></div>";
    include "includes/footer.php";
    exit;
}

$order->create((int)$_SESSION['user_id'], $total_amount, 'done');
$order_id = $order->getOrderId();

if (empty($order_id)) {
    echo "<div class='container'><div class='alert alert-danger'>Unable to create order. Please try again later.</div></div>";
    include "includes/footer.php";
    exit;
}

$failed_items = [];
foreach ($cart as $product_id => $item) {
    $orderItem = new OrderItem($connection);
    $ok = $orderItem->create($order_id, (int)$item['product_id'], (int)$item['quantity'], (float)$item['price']);
    if (!$ok) {
        $failed_items[] = $item;
    }
}

// Attempt to deduct stock for each item after creating order items
$stock_errors = [];
foreach ($cart as $product_id => $item) {
    $pid = (int)$item['product_id'];
    $qty = (int)$item['quantity'];

    $stmt = mysqli_prepare($connection, "UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ? AND stock_quantity >= ?");
    if ($stmt) {
        $stmt->bind_param('iii', $qty, $pid, $qty);
        $stmt->execute();
        if ($stmt->affected_rows === 0) {
            // failed to deduct, possibly due to race condition
            $stock_errors[] = $item;
        }
    } else {
        $stock_errors[] = $item;
    }
}

// Clear cart after successful creation (only if no failures saving items or stock failures)
if (empty($failed_items) && empty($stock_errors)) {
    unset($_SESSION['cart']);
}

if (!empty($stock_errors)) {
    echo "<div class='container'><div class='alert alert-warning'>Order placed but could not deduct stock for some items. Please contact support.</div></div>";
}

// Try to send confirmation email to user (if we can determine email)
$user_email = null;
$user_name = null;
if (isset($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    $uQ = mysqli_prepare($connection, "SELECT user_firstname, user_lastname, user_email FROM users WHERE user_id = ?");
    if ($uQ) {
        $uQ->bind_param('i', $uid);
        $uQ->execute();
        $res = $uQ->get_result();
        if ($row = $res->fetch_assoc()) {
            $user_email = $row['user_email'] ?? null;
            $user_name = trim(($row['user_firstname'] ?? '') . ' ' . ($row['user_lastname'] ?? '')) ?: ($_SESSION['username'] ?? '');
        }
    }
}

if ($user_email) {
    $subject = "Order Confirmation #" . $order_id;
    $html = "<h2>Order Confirmation</h2>";
    $html .= "<p>Hi " . htmlspecialchars($user_name) . ",</p>";
    $html .= "<p>Thank you for your order. Your order number is <strong>#" . htmlspecialchars($order_id) . "</strong>.</p>";
    $html .= "<h4>Order Summary</h4>";
    $html .= "<table style='width:100%;border-collapse:collapse;' border='1'><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody>";
    foreach ($cart as $item) {
        $subtotal = $item['price'] * $item['quantity'];
        $html .= "<tr><td>" . htmlspecialchars($item['name']) . "</td><td>$" . number_format($item['price'],2) . "</td><td>" . (int)$item['quantity'] . "</td><td>$" . number_format($subtotal,2) . "</td></tr>";
    }
    $html .= "</tbody></table>";
    $html .= "<p><strong>Total: $" . number_format($total_amount, 2) . "</strong></p>";
    $html .= "<p>If you have any questions, reply to this email.</p>";

    // Use send_mail wrapper (prefers SMTP when MAIL_USE_SMTP is true)
    $sent = send_mail($user_email, $user_name ?: $user_email, $subject, $html, strip_tags($html));
    if ($sent) {
        echo "<div class='container'><div class='alert alert-success'>A confirmation email has been sent to " . htmlspecialchars($user_email) . "</div></div>";
    } else {
        echo "<div class='container'><div class='alert alert-warning'>Order placed but confirmation email could not be sent. Check mail configuration.</div></div>";
    }
} else {
    echo "<div class='container'><div class='alert alert-info'>Order placed. We couldn't find your email to send a confirmation.</div></div>";
}

?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <h1 class="page-header">Order Confirmation</h1>

            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Thank you — your order has been placed</h3>
                </div>
                <div class="panel-body">
                    <p>Your order number is <strong>#<?php echo htmlspecialchars($order_id); ?></strong>.</p>
                    <p>Total amount: <strong>$<?php echo number_format($total_amount, 2); ?></strong></p>
                    <?php if (!empty($failed_items)) { ?>
                        <div class="alert alert-warning">Some items could not be saved. Please contact support.</div>
                    <?php } ?>
                    <h4>Order Items</h4>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart as $item) {
                                $subtotal = $item['price'] * $item['quantity']; ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo (int)$item['quantity']; ?></td>
                                    <td>$<?php echo number_format($subtotal, 2); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                    <a href="shop.php" class="btn btn-primary">Continue Shopping</a>
                    <a href="index.php" class="btn btn-default">Return Home</a>
                </div>
            </div>
        </div>
    </div>
</div>